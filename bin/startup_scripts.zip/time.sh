#!/bin/sh
while true
do
notify-send -u normal "$(date +"%H:%M")"
sleep 1200
done
