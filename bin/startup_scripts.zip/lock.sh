#!/bin/sh
swayidle -w \
timeout 200 'swaylock -f -c 000000' \
timeout 250 'swaymsg "output * dpms off"' resume 'swaymsg "output * dpms on"' \
timeout 300 'systemctl suspend' before-sleep 'swaylock -f -c 000000'
