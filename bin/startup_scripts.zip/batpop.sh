#!/bin/sh

dunst &

while true
 do
    notify-send -u low  "$(acpi)"   
   sleep 300
 done

