#!/bin/sh

dunst &
/home/kunal/.local/bin/time.sh &
/home/kunal/.local/bin/batpop.sh &
